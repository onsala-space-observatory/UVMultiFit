S = [1.000e+00, 2.000e-01, -1.500e+00, 5.000e-01, 4.000e-01]
immname = 'TEST6.CLEAN.residual'
psfname = 'TEST6.CLEAN.psf'
modelshape = ['Gaussian','Gaussian']
modvars = ['0.,0.,p[0],p[1],1.,0.','0.,p[2],p[3],p[4],1.,0.']
pini = [7.000e-01, 2.600e-01, -1.125e+00, 6.000e-01, 5.200e-01]
parbound = [[0.,None],[0.,None],[-15,15],[0.,None],[0.,None]]
import time

tic = time.time()

myfit = uvm.immultifit(residual = immname, psf = psfname,
               model = modelshape, OneFitPerChannel = False,
               var = modvars,write='residuals',
               p_ini = pini,LMtune=[1.e-3,10.,1.e-8,200,1.e-5],
               bounds=parbound)
msg = ''

for pi in range(len(pini)):
  msg += '\n Parameter %i: %.4f +/- %.4f | True value %.2f'%(pi,myfit.result['Parameters'][pi],myfit.result['Uncertainties'][pi],S[pi])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

resf = open('test6.dat','w')
print >> resf,'\n\n\nTEST 6: IMMULTIFIT\n'
print >> resf, msg
resf.close()



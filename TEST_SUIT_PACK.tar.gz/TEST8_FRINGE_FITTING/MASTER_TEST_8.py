import numpy as np
import scipy as sp
import pylab as pl
import os
from simutil import *


# TEST 8: FRINGE FITTING 

# What to do:
#DoSimObs = False
#DoFit = True
#casaexe='casa --nologger'



# Fringe-Fit only these scans:
DOSCANs = [1]  # range(1,13)


# Array to use:
VLBAarr = """# observatory=VLBA\n# coordsys=XYZ
 -2112065.169063  3705356.505980  4726813.681152  25.  BR
 -1324009.296014  5332181.961648  3231962.393635  25.  FD
 -1995678.809977  5037317.705238  3357328.030390  25.  KP
 -1449752.549265  4975298.582200  3709123.846349  25.  LA
 -5464075.148965  2495248.295195  2148297.249841  25.  MK
  -130872.458404  4762317.103627  4226850.996905  25.  NL
 -2409150.357597  4478573.142538  3838617.335974  25.  OV
 -1640953.908700  5014816.029130  3575411.783269  25.  PT
  2607848.614131  5488069.569639  1932739.681584  25.  SC
"""

# Gains to solve for:

              # Tau (ns)  Rate(mHz)   Phase (deg)
GAINS = {'BR':   [ 2.0,        60.,        20.],
         'FD':   [-2.0,       -30.,       -40.],
         'KP':   [ 3.0,       -10.,       170.],
         'LA':   [-3.0,        40.,         5.],
         'MK':   [ 0.5,        20.,       -20.],
         'NL':   [ 0.7,       -15.,        10.],
         'OV':   [-0.6,        10.,        -4.],
         'PT':   [ 1.4,        12.,        90.],
         'SC':   [-1.2,       -30.,       -90.]}

REFANT = 'LA'

# Name of MS:
imname = 'Compact_Source'


#########################
# SIMULATION PARAMETERS:

# On-source observing time:
TObs = 1.0 # in hr

# integration time (per visib.)
Tint = '2s'  

# Duration of duty cycles:
Duty = 500.  # in seconds

# On-source time per duty cycle:
DutyON = 300. # in seconds

# Source and array:
Coords = '10h00m00.0s 30d00m00.0s'
Hcenter =  0.0 # Hour angle at center of observations
Array = 'VLBA.array'
NU = '5.0GHz' ; dNU = '0.25MHz'; Nchan = 128  # IF FREQ AND WIDTH
TSYS = 60.  # in K.
tau0 = 0.01
seed = 42 # Random seed
ADD_NOISE = True









#################
# SCRIPT STARTS #
#################




# Write the array file:
arf = open('VLBA.array','w')
print >> arf,VLBAarr
arf.close()


# Re-write gains in right units:
for ant in GAINS.keys():
  GAINS[ant][0] *= 1.e-9
  GAINS[ant][1] *= 1.e-3 #/qa.convertfreq(NU)['value']
  GAINS[ant][2] *= np.pi/180.


mas2rad = np.pi/180./3600./1000.

if DoSimObs:

  print 'Generating %s'%imname

  print ' SETTING ANTENNA PARAMETERS'
  util = simutil('')
  stnx, stny, stnz, stnd, padnames, arrname, arrpos = util.readantenna(Array)
  eta_p, eta_s, eta_b, eta_t, eta_q, t_rx = util.noisetemp(telescope='VLBA',freq=NU)
  eta_a = eta_p * eta_s * eta_b * eta_t

  print '\n\n RESETTING THE TSYS TO %.1f K.\n\n'%TSYS
  t_rx = TSYS
  t_sky = 260.
  t_ground = 260.


################################################
# Prepare template measurement set:
  print '\n\n PREPARING MS TEMPLATE\n\n'

  VLBA = me.observatory('VLBA')
  mount = 'alt-az'
  refdate='2017/01/01/00:00:00'
  usehourangle = True

  os.system('rm -rf %s.ms'%imname)
  sm.open('%s.ms'%imname)

  sm.setconfig(telescopename='VLBA', x=stnx, y=stny, z=stnz,
             dishdiameter=stnd.tolist(),
             mount=mount, antname=padnames, padname=padnames, 
             coordsystem='global', referencelocation=VLBA)

  sm.setspwindow(spwname='spw0', freq=NU, deltafreq=dNU,
               freqresolution=dNU, 
               nchannels=Nchan, refcode="BARY",
               stokes='RR LL')

  sm.setfield(sourcename="FFTarget", sourcedirection=Coords,
          calcode="TARGET", distance='0m')


  mereftime = me.epoch('TAI', refdate)

  print ' Will shift the date of observation to match the Hour Angle range\n'

  sm.settimes(integrationtime=Tint, usehourangle=usehourangle, 
            referencetime=mereftime)


# Figure out scan distribution:
  NSCAN = int(TObs*3600./DutyON)
  Ttot = NSCAN*Duty
  print '\n\n  Total duration of experiment: %.2f h (%i scans)\n\n'%(Ttot/3600.,NSCAN)

  T0s = [Hcenter*3600. + Ttot*(i-NSCAN/2.)/NSCAN for i in range(NSCAN)]

  starttimes = []
  stoptimes = []
  sources = []
  for i in range(NSCAN):
    sttime = T0s[i]
    endtime = (sttime + Duty)
    starttimes.append(str(sttime)+'s')
    stoptimes.append(str(endtime)+'s')
    sources.append("FFTarget")

  for n in range(NSCAN):
    sm.observemany(sourcenames=[sources[n]],spwname='spw0',starttimes=[starttimes[n]],stoptimes=[stoptimes[n]],project='UVFIT_TEST')
  
  sm.close()

################################################



#if True:
################################################
# Apply the gains to the data:

  print '\n\n WRITING VISIBILITIES \n\n'

  tb.open(imname+'.ms/ANTENNA')
  ANTNAMES = tb.getcol('NAME')
  tb.close()

  tb.open(imname+'.ms/SPECTRAL_WINDOW')
  FREQS = tb.getcol('CHAN_FREQ')[:,0]
  FREQS -= FREQS[0]
  tb.close()

  tb.open(imname+'.ms', nomodify=False)

  A1 = tb.getcol('ANTENNA1')
  A2 = tb.getcol('ANTENNA2')
  T = tb.getcol('TIME')
  T -= T[0]


  GARR = np.zeros((len(ANTNAMES),3))
  for ant in range(len(ANTNAMES)):
    GARR[ant,:] = GAINS[ANTNAMES[ant]]

  for i in range(len(T)):
    if not i%1000:
      sys.stdout.write('\r  Writing vis #%i of %i'%(i,len(T)))
      sys.stdout.flush()
    DELAY = GARR[A1[i]][0] - GARR[A2[i]][0]
    RATE =  GARR[A1[i]][1] - GARR[A2[i]][1]
    PHASE = GARR[A1[i]][2] - GARR[A2[i]][2]
    TOTPHASE = 2.*np.pi*(DELAY*FREQS + RATE*T[i]) + PHASE
    DATA = tb.getcell('DATA',i)
    DATA[0,:] = np.exp(1.j*TOTPHASE)
    DATA[1,:] = np.exp(-1.j*TOTPHASE)
    tb.putcell('DATA',i,DATA)

  tb.close()


# Add noise:

  print '\n\n Corrupting data...\n'

  os.system('rm -rf %s.noisy.ms'%imname)
  os.system('cp -r %s.ms %s.noisy.ms'%(imname,imname))

  sm.openfromms('%s.noisy.ms'%imname)
  sm.setdata(fieldid=0,spwid=0)   
  sm.setseed(seed)
  sm.setnoise(spillefficiency=eta_s,correfficiency=eta_q,
                 antefficiency=eta_a,trx=t_rx,
                 tau=tau0,tatmos=t_sky,tground=t_ground,tcmb=2.725,
                 mode="tsys-manual",senscoeff=-1)
  sm.corrupt()
  sm.done()

  clearcal('%s.noisy.ms'%imname,addmodel=True)





if DoFit:
  
  import time

  ANTS = GAINS.keys()

  tb.open(imname+'.noisy.ms/ANTENNA')
  ANTNAMES = tb.getcol('NAME')
  tb.close()

  allgains = {}
  ai = 0
  ri = -1
  for ant in range(len(ANTNAMES)):
    pc = 3*ai
    if ANTNAMES[ant] != REFANT:
      allgains[ant] = '2.*3.1416*(p[%i]*(nu - nu0)*(1.e-9) + p[%i]*t) + p[%i]'%(pc,pc+1,pc+2)
      ai += 1
    else:
      ri = ant

  Npar = len(allgains.keys())*3

  message = 'GLOBAL FRINGE FITTING:\n' 

  fitTime = 0

  for DOSCAN in DOSCANs:

    tic = time.time()

    message += '\n##############\n   SCAN   %i\n##############\n\n'%DOSCAN

    myfit = uvm.uvmultifit(vis='%s.noisy.ms'%imname, spw='0', column='data',scans = [DOSCAN],
                 stokes = 'RR', model = ['delta'], var=['0,0,1'], write='model',
                 p_ini=[0.0 for i in range(Npar)], OneFitPerChannel=False, finetune=True,
                 phase_gains = allgains,LMtune=[1.e-3,10.,1.e-4,5,1.e-3])


    QGains = myfit.QuinnFF(0,ri,0,1)
    nu = qa.convertfreq(NU)['value']
    r2d = 180./np.pi
    twopi = 2.*np.pi
    pini = []
    bounds = []
#Antenna 0 -> Rate: 6.925e-310 Hz; Delay: 6.925e-310 s.
#Antenna 1 -> Rate: -1.848e-11 Hz; Delay: -4.031e-09 s.
#Antenna 2 -> Rate: -1.415e-11 Hz; Delay: 1.008e-09 s.
#Antenna 3 -> Rate: -3.966e-12 Hz; Delay: -5.038e-09 s.
#Antenna 4 -> Rate: -1.159e-11 Hz; Delay: -1.512e-09 s.
#Antenna 5 -> Rate: -1.326e-11 Hz; Delay: -1.310e-09 s.
#Antenna 6 -> Rate: -9.890e-12 Hz; Delay: -2.620e-09 s.
#Antenna 7 -> Rate: -9.848e-12 Hz; Delay: -6.046e-10 s.
#Antenna 8 -> Rate: -1.304e-11 Hz; Delay: -3.225e-09 s.

    if QGains != -1:
      Dtau = QGains[3] ; DRate = QGains[4]
      message += '\n\n From Quinn Fringing (though phases are not globalized!): \nAntenna | Quantity     |  True       |  Quinn Est. |   Difference  \n\n'
      for ant in range(len(ANTS)):
        an = ANTNAMES[ant]

        ph = (GAINS[an][2] - GAINS[REFANT][2])*r2d
        de = (GAINS[an][0] - GAINS[REFANT][0])*1.e9
        rt = (GAINS[an][1] - GAINS[REFANT][1])*1.e3

        fph = QGains[2][ant]*r2d
        fde = QGains[0][ant]*1.e9
        frt = QGains[1][ant]*1.e3

        if an != REFANT:
          pini += [QGains[0][ant]*1.e9, QGains[1][ant], QGains[2][ant]]
          bounds += [[pini[-3]-Dtau,pini[-3]+Dtau],[pini[-2]-DRate,pini[-2]+DRate],[-twopi,twopi]]
        dph = ph-fph
        if dph>180.:
          dph -= 360.
        if dph<-180.:
          dph += 360.

        message += '  %s    |  Delay (ns)  |  % 9.3f  |  % 9.3f  |  % 9.3f \n'%(an,de,fde,de-fde)
        message += '  %s    |  Rate (mHz)  |  % 9.3f  |  % 9.3f  |  % 9.3f \n'%(an,rt,frt,rt-frt)
        message += '  %s    |  Phase (deg) |  % 9.3f  |  % 9.3f  |  % 9.3f \n\n'%(an,ph,fph,dph)

    else:

      message = '\n\n Quinn-based Fringe Fitting is not compiled!\n Will set a-prioris to TRUE values!'   
      for ant in range(len(ANTS)):
        an = ANTNAMES[ant]
        ph = (GAINS[an][2] - GAINS[REFANT][2])
        de = (GAINS[an][0] - GAINS[REFANT][0])
        rt = (GAINS[an][1] - GAINS[REFANT][1])
        if ANTNAMES[ant] != REFANT:
          pini += [de*1.e9, rt, ph]


    print message

    myfit.p_ini = pini
    myfit.bounds = bounds
    myfit.checkInputs()
    myfit.fit()

    myfit.writeModel()

    FittedGains = []
    pf = 0
    for pi in range(len(ANTNAMES)):
      FittedGains.append([])

      if ANTNAMES[pi] != REFANT:
        FittedGains[-1] = myfit.result['Parameters'][3*pf:3*pf+3]
        pf += 1
      else:
        FittedGains[-1] = [0.,0.,0.]




    message += '\n\n Least-Squares GFF: \nAntenna | Quantity     |  True       |  Global FF. |   Difference  \n\n'
    for ant in range(len(ANTS)):
      an = ANTNAMES[ant]

      ph = (GAINS[an][2] - GAINS[REFANT][2])*r2d
      de = (GAINS[an][0] - GAINS[REFANT][0])*1.e9
      rt = (GAINS[an][1] - GAINS[REFANT][1])*1.e3

      fph = FittedGains[ant][2]*r2d
      fde = FittedGains[ant][0]
      frt = FittedGains[ant][1]*1.e3

      dph = ph-fph
      if dph>180.:
        dph -= 360.
        fph += 360.
      if dph<-180.:
        dph += 360.
        fph -= 360.

      message += '  %s    |  Delay (ns)  |  % 9.3f  |  % 9.3f  |  % 9.3f \n'%(an,de,fde,de-fde)
      message += '  %s    |  Rate (mHz)  |  % 9.3f  |  % 9.3f  |  % 9.3f \n'%(an,rt,frt,rt-frt)
      message += '  %s    |  Phase (deg) |  % 9.3f  |  % 9.3f  |  % 9.3f \n\n'%(an,ph,fph,dph)

    tac = time.time()
    fitTime += tac-tic

    message += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

    print message

    print '\n NOW, CALIBRATING SCAN'

    ms.open('%s.noisy.ms'%imname,nomodify=False)
    ms.selectinit(datadescid=0)
    ms.select({'scan_number':DOSCAN})

    ALLDATS = ms.getdata(['data','corrected_data','model_data'])

    ALLDATS['corrected_data'][:] = ALLDATS['data']/ALLDATS['model_data']

    ms.putdata(ALLDATS)

    ms.close()

    print '\n PLOTTING...'

    tb.open('%s.noisy.ms'%imname)
    SCAN = tb.getcol('SCAN_NUMBER') == DOSCAN
    ANT1 = tb.getcol('ANTENNA1')[SCAN]
    ANT2 = tb.getcol('ANTENNA2')[SCAN]
    DATA = tb.getcol('DATA')[0,:,SCAN]
    CORRDATA = tb.getcol('CORRECTED_DATA')[0,:,SCAN]

    fig = pl.figure()
    fig.subplots_adjust(wspace=0.01,hspace=0.01)
    NPLOT = len(ANTNAMES)-1
    k = 0
    for i in range(len(ANTNAMES)):
     if ri != i:
      BASI = np.logical_or((ANT1==ri)*(ANT2==i),(ANT2==ri)*(ANT1==i))
      AverData = np.average(DATA[BASI,:],axis=0)
      sub = fig.add_subplot(2,NPLOT,k+1)
      sub.plot(np.angle(AverData)*r2d,'.r')
      pl.setp(sub.get_xticklabels(),'visible',False)
      if k>0:
       pl.setp(sub.get_yticklabels(),'visible',False)
      else:
       sub.set_ylabel('Phase (deg.)')
      pl.ylim((-180.,180.))
      sub.set_title(ANTNAMES[i])

      sub = fig.add_subplot(2,NPLOT,NPLOT + k+1)

      pl.setp(sub.get_xticklabels(),'visible',False)
      if k>0:
        pl.setp(sub.get_yticklabels(),'visible',False)
      else:
        sub.set_ylabel('Amp (Norm.)')
      pl.ylim((0.,1.5))

      sub.plot(np.abs(AverData),'-b')

      k += 1

    pl.savefig('TEST8.ORIGINAL_FRINGES_%i.png'%DOSCAN)

    fig = pl.figure()
    fig.subplots_adjust(wspace=0.01,hspace=0.01)
    NPLOT = len(ANTNAMES)-1
    k = 0
    for i in range(len(ANTNAMES)):
     if ri != i:
      BASI = np.logical_or((ANT1==ri)*(ANT2==i),(ANT2==ri)*(ANT1==i))
      AverData = np.average(CORRDATA[BASI,:],axis=0)
      sub = fig.add_subplot(2,NPLOT,k+1)
      sub.plot(np.angle(AverData)*r2d,'.r')
      pl.setp(sub.get_xticklabels(),'visible',False)
      if k>0:
        pl.setp(sub.get_yticklabels(),'visible',False)
      else:
        sub.set_ylabel('Phase (deg.)')
      pl.ylim((-180.,180.))
      sub.set_title(ANTNAMES[i])

      sub = fig.add_subplot(2,NPLOT,NPLOT + k+1)

      pl.setp(sub.get_xticklabels(),'visible',False)
      if k>0:
        pl.setp(sub.get_yticklabels(),'visible',False)
      else:
        sub.set_ylabel('Amp (Norm.)')
      pl.ylim((0.,1.5))

      sub.plot(np.abs(AverData),'-b')

      k += 1

    pl.savefig('TEST8.CALIBRATED_FRINGES_%i.png'%DOSCAN)

    del myfit

    resf = open('test8.dat','w')
    print >> resf,'\n\n\nTEST 8: GLOBAL FRINGE FITTING\n'
    print >> resf, message


  print >> resf, '  TOTAL FRINGING TIME:  %.2f SECONDS '%fitTime 
  resf.close()

  
